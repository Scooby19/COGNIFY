document.getElementById('colorButton').addEventListener('click', function() {
    document.body.style.backgroundColor = 'blanchedalmond';
});